# multiNorm 0.9.1

## Major changes

* And so it begins.
