library(testthat)
library(multiNorm)

test_check("multiNorm")
