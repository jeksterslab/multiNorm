## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(multiNorm)

## -----------------------------------------------------------------------------
set.seed(42)
n_i <- 1000
rcap_i <- 10
k_i <- sample(x = 2:10, size = 1)
mu_i <- rep(x = 0, times = k_i)
sigmacap_i <- toeplitz((k_i:1) / k_i)
theta_i <- c(
  mu_i,
  vech(sigmacap_i)
)
mu_i
sigmacap_i
sigmacap_i / n_i
theta_i

## -----------------------------------------------------------------------------
data_i <- rmeans_mvn_chol(
  rcap = rcap_i,
  mu = mu_i,
  sigmacap = sigmacap_i,
  n = n_i
)
data_i
colMeans(data_i)
cov(data_i)

## -----------------------------------------------------------------------------
data_i <- rmeans_mvn_chol_of_theta(
  rcap = rcap_i,
  x = theta_i,
  n = n_i
)
data_i
colMeans(data_i)
cov(data_i)

