## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(multiNorm)

## -----------------------------------------------------------------------------
set.seed(42)
n_i <- 1000000
k_i <- sample(x = 2:10, size = 1)
mu_i <- rep(x = 0, times = k_i)
rho_i <- runif(n = 1, min = -1, max = 1)
sigmacap_i <- matrix(
  data = rho_i,
  nrow = k_i,
  ncol = k_i
)
diag(sigmacap_i) <- 1
vech_i <- vech(sigmacap_i)
rhocap_i <- cov2cor(sigmacap_i)
vechs_i <- vechs(rhocap_i)
mu_i
sigmacap_i
vech_i
rhocap_i
vechs_i

## -----------------------------------------------------------------------------
data_i <- rmvn_chol(
  n = n_i,
  mu = mu_i,
  sigmacap = sigmacap_i
)
colMeans(data_i)
cov(data_i)

## -----------------------------------------------------------------------------
theta_i <- c(
  mu_i,
  vech(sigmacap_i)
)
data_i <- rmvn_chol_of_theta(
  n = n_i,
  x = theta_i
)
colMeans(data_i)
cov(data_i)

## -----------------------------------------------------------------------------
data_i <- rmvn_chol_of_rhocap(
  n = n_i,
  x = rhocap_i
)
colMeans(data_i)
cov(data_i)

## -----------------------------------------------------------------------------
data_i <- rmvn_chol_of_vechsrhocap(
  n = n_i,
  x = vechs_i
)
colMeans(data_i)
cov(data_i)

