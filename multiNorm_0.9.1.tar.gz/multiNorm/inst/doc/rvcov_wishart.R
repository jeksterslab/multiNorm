## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(multiNorm)

## -----------------------------------------------------------------------------
set.seed(42)
n_i <- 1000
df_i <- n_i - 1
rcap_i <- 10
k_i <- sample(x = 2:10, size = 1)
sigmacap_i <- toeplitz((k_i:1) / k_i)
vech_i <- vech(sigmacap_i)
sigmacap_i
vech_i
df_i

## -----------------------------------------------------------------------------
data_i <- rvcov_wishart(
  rcap = rcap_i,
  sigmacap = sigmacap_i,
  df = df_i,
  vector = FALSE
)
data_i

## -----------------------------------------------------------------------------
data_i <- rvcov_wishart(
  rcap = rcap_i,
  sigmacap = sigmacap_i,
  df = df_i,
  vector = TRUE
)
data_i

## -----------------------------------------------------------------------------
data_i <- rvcov_wishart_of_vechsigmacap(
  rcap = rcap_i,
  x = vech_i,
  df = df_i,
  vector = FALSE
)
data_i

## -----------------------------------------------------------------------------
data_i <- rvcov_wishart_of_vechsigmacap(
  rcap = rcap_i,
  x = vech_i,
  df = df_i,
  vector = TRUE
)
data_i

